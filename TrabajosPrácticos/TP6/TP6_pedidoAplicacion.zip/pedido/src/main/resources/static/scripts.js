document.addEventListener('DOMContentLoaded', function() {
    const localidades = {
        "Buenos Aires": ["La Plata", "Mar del Plata", "Bahía Blanca", "Tandil", "Olavarría"],
        "Catamarca": ["San Fernando del Valle", "Belén", "Tinogasta", "Andalgalá", "Santa María"],
        "Chaco": ["Resistencia", "Charata", "Saenz Peña", "Pampa del Indio", "Villa Ángela"],
        "Chubut": ["Rawson", "Comodoro Rivadavia", "Trelew", "Esquel", "Puerto Madryn"],
        "CABA": ["Ciudad Autónoma de Buenos Aires"], // Capital Federal
        "Córdoba": ["Córdoba Capital", "Villa María", "Río Cuarto", "San Francisco", "Alta Gracia"],
        "Corrientes": ["Corrientes Capital", "Goya", "Mercedes", "Paso de los Libres", "Monte Caseros"],
        "Entre Ríos": ["Paraná", "Concordia", "Gualeguaychú", "Colón", "Federación"],
        "Formosa": ["Formosa Capital", "Clorinda", "El Colorado", "Pirané", "Villa Escolar"],
        "Jujuy": ["San Salvador de Jujuy", "Palpala", "La Quiaca", "Perico", "El Carmen"],
        "La Pampa": ["Santa Rosa", "General Pico", "Eduardo Castex", "Victorica", "Realicó"],
        "La Rioja": ["La Rioja Capital", "Chilecito", "Famatina", "Sanagasta", "Villa Unión"],
        "Mendoza": ["Mendoza Capital", "San Rafael", "Godoy Cruz", "Maipú", "Luján de Cuyo"],
        "Misiones": ["Posadas", "Oberá", "Eldorado", "San Vicente", "Montecarlo"],
        "Neuquén": ["Neuquén Capital", "San Martín de los Andes", "Villa La Angostura", "Zapala", "Rincón de los Sauces"],
        "Río Negro": ["Viedma", "San Carlos de Bariloche", "General Roca", "Cipolletti", "El Bolsón"],
        "Salta": ["Salta Capital", "San Salvador de Jujuy", "Orán", "Cafayate", "Rosario de la Frontera"],
        "San Juan": ["San Juan Capital", "Rivadavia", "Rawson", "Zonda", "Chimbas"],
        "San Luis": ["San Luis Capital", "Villa Mercedes", "La Punta", "Merlo", "Justo Daract"],
        "Santa Cruz": ["Río Gallegos", "Caleta Olivia", "El Chaltén", "El Calafate", "Puerto Deseado"],
        "Santa Fe": ["Santa Fe Capital", "Rosario", "Venado Tuerto", "Rafaela", "San Lorenzo"],
        "Santiago del Estero": ["Santiago del Estero Capital", "La Banda", "Termas de Río Hondo", "Añatuya", "Frías"],
        "Tierra del Fuego": ["Ushuaia", "Río Grande", "Tolhuin", "Puerto Almanza", "Las Heras"],
        "Tucumán": ["San Miguel de Tucumán", "Tafí Viejo", "Concepción", "Yerba Buena", "Simoca"]
    };

    function cargarProvincias() {
        const provincias = Object.keys(localidades);
        const provinciaRetiroSelect = document.getElementById('domicilioRetiroProvincia');
        const provinciaEntregaSelect = document.getElementById('domicilioEntregaProvincia');

        provincias.forEach(function(provincia) {
            const option = document.createElement('option');
            option.value = provincia;
            option.textContent = provincia;
            provinciaRetiroSelect.appendChild(option);
            provinciaEntregaSelect.appendChild(option.cloneNode(true)); // Clona la opción para el segundo dropdown
        });
    }

    function actualizarLocalidades(provinciaSeleccionada, selectLocalidadId) {
        const localidadSelect = document.getElementById(selectLocalidadId);
        localidadSelect.innerHTML = '<option value="">Seleccione la localidad</option>';
        if (provinciaSeleccionada && localidades[provinciaSeleccionada]) {
            localidades[provinciaSeleccionada].forEach(function(localidad) {
                const option = document.createElement('option');
                option.value = localidad;
                option.textContent = localidad;
                localidadSelect.appendChild(option);
            });
        }
    }

    document.getElementById('domicilioRetiroProvincia').addEventListener('change', function() {
        const provinciaSeleccionada = this.value;
        actualizarLocalidades(provinciaSeleccionada, 'domicilioRetiroLocalidad');
    });

    document.getElementById('domicilioEntregaProvincia').addEventListener('change', function() {
        const provinciaSeleccionada = this.value;
        actualizarLocalidades(provinciaSeleccionada, 'domicilioEntregaLocalidad');
    });

    // Inicializar provincias al cargar la página
    cargarProvincias();

    const fechaRetiroInput = document.getElementById('fechaRetiro');
    const hoy = new Date();
    const unMesDesdeHoy = new Date(hoy);
    unMesDesdeHoy.setMonth(hoy.getMonth() + 1);
    const hoyFormato = hoy.toISOString().split('T')[0];
    const unMesDesdeHoyFormato = unMesDesdeHoy.toISOString().split('T')[0];
    fechaRetiroInput.setAttribute('min', hoyFormato);
    fechaRetiroInput.setAttribute('max', unMesDesdeHoyFormato);

    document.getElementById('pedidoForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const tipoCarga = document.getElementById('tipoCarga').value;
        const domicilioRetiro = {
            provincia: document.getElementById('domicilioRetiroProvincia').value,
            localidad: document.getElementById('domicilioRetiroLocalidad').value,
            calle: document.getElementById('domicilioRetiroCalle').value,
            numero: document.getElementById('domicilioRetiroNumero').value,
            otros: document.getElementById('domicilioRetiroOtros').value
        };
        const fechaRetiro = new Date(document.getElementById('fechaRetiro').value);
        const domicilioEntrega = {
            provincia: document.getElementById('domicilioEntregaProvincia').value,
            localidad: document.getElementById('domicilioEntregaLocalidad').value,
            calle: document.getElementById('domicilioEntregaCalle').value,
            numero: document.getElementById('domicilioEntregaNumero').value,
            otros: document.getElementById('domicilioEntregaOtros').value
        };
        const fechaEntrega = new Date(document.getElementById('fechaEntrega').value);

        //Este es el arreglo para que tome el dia de hoy
        const hoy = new Date();
        // Restar un día
        hoy.setDate(hoy.getDate() - 1);
        // Establecer la hora a 23:59:59
        hoy.setHours(20, 50, 59, 999);



        if (fechaRetiro < hoy) {
            document.getElementById('error').classList.remove('d-none');
            document.getElementById('error').innerText = 'Error: La fecha de retiro no puede ser anterior a hoy.';
            return;
        }

        if (fechaEntrega < fechaRetiro) {
            document.getElementById('error').classList.remove('d-none');
            document.getElementById('error').innerText = 'Error: La fecha de entrega no puede ser anterior a la fecha de retiro.';
            return;
        }

        const diezDias = 10 * 24 * 60 * 60 * 1000;
        if (fechaEntrega > new Date(fechaRetiro.getTime() + diezDias)) {
            document.getElementById('error').classList.remove('d-none');
            document.getElementById('error').innerText = 'Error: La fecha de entrega debe ser dentro de los 10 días posteriores a la fecha de retiro.';
            return;
        }

        document.getElementById('error').classList.add('d-none');

        const formData = new FormData();
        formData.append('tipoCarga', tipoCarga);
        formData.append('domicilioRetiroProvincia', domicilioRetiro.provincia);
        formData.append('domicilioRetiroLocalidad', domicilioRetiro.localidad);
        formData.append('domicilioRetiroCalle', domicilioRetiro.calle);
        formData.append('domicilioRetiroNumero', domicilioRetiro.numero);
        formData.append('domicilioRetiroOtros', domicilioRetiro.otros);
        formData.append('fechaRetiro', fechaRetiro.toISOString().split('T')[0]); // Solo fecha
        formData.append('domicilioEntregaProvincia', domicilioEntrega.provincia);
        formData.append('domicilioEntregaLocalidad', domicilioEntrega.localidad);
        formData.append('domicilioEntregaCalle', domicilioEntrega.calle);
        formData.append('domicilioEntregaNumero', domicilioEntrega.numero);
        formData.append('domicilioEntregaOtros', domicilioEntrega.otros);
        formData.append('fechaEntrega', fechaEntrega.toISOString().split('T')[0]); // Solo fecha


        const fotosInput = document.getElementById('fotos');
        if (fotosInput.files.length > 0) {
            Array.from(fotosInput.files).forEach(file => {
                formData.append('fotos', file);
            });
        }

        fetch('/api/pedidos', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success
                    && document.getElementById('error') !== 'Error: La fecha de retiro no puede ser anterior a hoy.'
                    && document.getElementById('error') !== 'Error: La fecha de entrega no puede ser anterior a la fecha de retiro.'
                    && document.getElementById('error') !== 'Error: La fecha de entrega debe ser dentro de los 10 días posteriores a la fecha de retiro.') {

                    //document.getElementById('notificacion').classList.remove('d-none');

                    // Mostrar la notificación
                    const notificacion = document.getElementById('notificacion');
                    notificacion.classList.remove('d-none');

                    // Ocultar el mensaje de notificación después de 5 segundos (5000 ms)
                    setTimeout(function() {
                        notificacion.classList.add('d-none');
                    }, 5000);

                    document.getElementById('pedidoForm').reset();

                } else {
                    document.getElementById('error').classList.remove('d-none');
                    document.getElementById('error').innerText = 'Hubo un error al enviar el pedido. Por favor, intente nuevamente.';
                }
            })
            .catch(() => {
                document.getElementById('error').classList.remove('d-none');
                document.getElementById('error').innerText = 'Hubo un error al enviar el pedido. Por favor, intente nuevamente.';
            });
    });
});
